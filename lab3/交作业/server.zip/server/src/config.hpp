#ifndef __CONFIG_HPP__
#define __CONFIG_HPP__


#define BUFFER_SIZE 64
#define USER_LIMIT 5
#define FD_LIMIT 65535

#endif // __CONFIG_HPP__